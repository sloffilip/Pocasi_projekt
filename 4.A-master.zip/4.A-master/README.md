# Programování, 4.A

Praktické příklady a zadání projektů do předmětu Programování pro třídu 4.A (školní rok 2023/4) [brněnské pobočky střední školy EDUCAnet](https://brno.educanet.cz/cs/).
