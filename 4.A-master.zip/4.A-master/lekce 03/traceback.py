# Ukázka výpisu chybového hlášení (tracebacku).

def calculate(n):
    return 2 * inverse(n)

def inverse(divider):
    return 1 / divider

calculate(0)
